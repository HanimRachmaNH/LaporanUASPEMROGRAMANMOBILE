from typing import Optional, List
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import sqlite3
import logging

logging.basicConfig(level=logging.INFO)

app = FastAPI()
DB_NAME = "sugarcare.db"

# Tambahkan CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Models
class Artikel(BaseModel):
    id: Optional[int]
    title: str
    snippet: str
    likes: int
    views: int
    imagepath: str
    isiartikels: str

class User(BaseModel):
    username: str
    email: str
    password: str

class BloodSugarRecord(BaseModel):
    id: Optional[int] = None
    dateTime: str
    blood_sugar_level: float
    period: str
    before_meal: bool
    notes: Optional[str]

# Helper function to add a column if it doesn't exist
def add_column_if_not_exists():
    try:
        con = sqlite3.connect(DB_NAME)
        cur = con.cursor()
        cur.execute("PRAGMA table_info(artikel)")
        columns = [column[1] for column in cur.fetchall()]
        if "isiartikels" not in columns:
            cur.execute("ALTER TABLE artikel ADD COLUMN isiartikels TEXT")
        con.commit()
    except Exception as e:
        logging.error(f"Error adding column: {str(e)}")
    finally:
        con.close()

# Initialize the database (create tables)
@app.get("/init/")
def init_db():
    try:
        con = sqlite3.connect(DB_NAME)
        cur = con.cursor()
        
        # Create artikel table
        create_artikel_table = """CREATE TABLE IF NOT EXISTS artikel (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                snippet TEXT NOT NULL,
                likes INTEGER NOT NULL,
                views INTEGER NOT NULL,
                imagepath TEXT NOT NULL,
                isiartikels TEXT
            )"""
        cur.execute(create_artikel_table)
        
        # Create user table
        create_user_table = """CREATE TABLE IF NOT EXISTS user (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                email TEXT NOT NULL,
                password TEXT NOT NULL
            )"""
        cur.execute(create_user_table)

        # Create blood sugar records table
        create_blood_sugar_table = """CREATE TABLE IF NOT EXISTS blood_sugar (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                dateTime TEXT NOT NULL,
                blood_sugar_level REAL NOT NULL,
                period TEXT NOT NULL,
                before_meal INTEGER NOT NULL,
                notes TEXT
            )"""
        cur.execute(create_blood_sugar_table)

        # Ensure the column isiartikels exists
        add_column_if_not_exists()

        con.commit()
    except Exception as e:
        logging.error(f"Error initializing database: {str(e)}")
        return {"status": f"Error occurred: {str(e)}"}
    finally:
        con.close()
    return {"status": "Database initialized, tables created"}

# CRUD for Artikel
@app.post("/artikels/")
def create_artikel(artikel: Artikel):
    try:
        con = sqlite3.connect(DB_NAME)
        cur = con.cursor()
        cur.execute("INSERT INTO artikel (title, snippet, likes, views, imagepath, isiartikels) VALUES (?, ?, ?, ?, ?, ?)",
                    (artikel.title, artikel.snippet, artikel.likes, artikel.views, artikel.imagepath, artikel.isiartikels))
        con.commit()
        artikel_id = cur.lastrowid
    except Exception as e:
        logging.error(f"Error creating artikel: {str(e)}")
        return {"status": "terjadi error", "detail": str(e)}
    finally:
        con.close()
    return {"id": artikel_id}

@app.get("/artikels/", response_model=List[Artikel])
def read_artikels():
    try:
        con = sqlite3.connect(DB_NAME)
        cur = con.cursor()
        cur.execute("SELECT * FROM artikel")
        artikels = cur.fetchall()
    except Exception as e:
        logging.error(f"Error reading artikels: {str(e)}")
        return {"status": "terjadi error", "detail": str(e)}
    finally:
        con.close()
    
    artikel_list = []
    for artikel in artikels:
        artikel_obj = Artikel(
            id=artikel[0],
            title=artikel[1],
            snippet=artikel[2],
            likes=artikel[3],
            views=artikel[4],
            imagepath=artikel[5],
            isiartikels=artikel[6]
        )
        artikel_list.append(artikel_obj)
    
    return artikel_list

@app.put("/artikels/{artikel_id}")
def update_artikel(artikel_id: int, artikel: Artikel):
    try:
        con = sqlite3.connect(DB_NAME)
        cur = con.cursor()
        cur.execute("UPDATE artikel SET title = ?, snippet = ?, likes = ?, views = ?, imagepath = ?, isiartikels = ? WHERE id = ?",
                    (artikel.title, artikel.snippet, artikel.likes, artikel.views, artikel.imagepath, artikel.isiartikels, artikel_id))
        con.commit()
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="Artikel not found")
    except Exception as e:
        logging.error(f"Error updating artikel: {str(e)}")
        return {"status": "terjadi error", "detail": str(e)}
    finally:
        con.close()
    return {"status": "Artikel updated successfully"}

@app.delete("/artikels/{artikel_id}")
def delete_artikel(artikel_id: int):
    try:
        con = sqlite3.connect(DB_NAME)
        cur = con.cursor()
        cur.execute("DELETE FROM artikel WHERE id = ?", (artikel_id,))
        con.commit()
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="Artikel not found")
    except Exception as e:
        logging.error(f"Error deleting artikel: {str(e)}")
        return {"status": "terjadi error", "detail": str(e)}
    finally:
        con.close()
    return {"status": "Artikel deleted successfully"}

# CRUD for BloodSugarRecord
@app.post("/save_record/", response_model=dict)
def save_record(record: BloodSugarRecord):
    try:
        con = sqlite3.connect(DB_NAME)
        cur = con.cursor()
        cur.execute("INSERT INTO blood_sugar (dateTime, blood_sugar_level, period, before_meal, notes) VALUES (?, ?, ?, ?, ?)",
                    (record.dateTime, record.blood_sugar_level, record.period, record.before_meal, record.notes))
        con.commit()
        record_id = cur.lastrowid
    except Exception as e:
        logging.error(f"Error saving record: {str(e)}")
        return {"status": "Error occurred", "detail": str(e)}
    finally:
        con.close()
    return {"id": record_id}

# Endpoint to retrieve all blood sugar records
@app.get("/get_records/", response_model=List[BloodSugarRecord])
def get_records():
    try:
        con = sqlite3.connect(DB_NAME)
        cur = con.cursor()
        cur.execute("SELECT * FROM blood_sugar")
        records = cur.fetchall()
    except Exception as e:
        logging.error(f"Error fetching records: {str(e)}")
        raise HTTPException(status_code=500, detail="Error fetching records")
    finally:
        con.close()

    # Mapping fetched records to BloodSugarRecord model
    blood_sugar_records = []
    for record in records:
        blood_sugar_record = BloodSugarRecord(
            id=record[0],
            dateTime=record[1],
            blood_sugar_level=record[2],
            period=record[3],
            before_meal=bool(record[4]),
            notes=record[5]
        )
        blood_sugar_records.append(blood_sugar_record)
        logging.info(f"Record fetched: {blood_sugar_record}")
    return blood_sugar_records

@app.delete("/delete_record/{record_id}", response_model=dict)
def delete_record(record_id: int):
    try:
        con = sqlite3.connect(DB_NAME)
        cur = con.cursor()
        cur.execute("DELETE FROM blood_sugar WHERE id = ?", (record_id,))
        con.commit()
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="Record not found")
    except Exception as e:
        logging.error(f"Error deleting record: {str(e)}")
        return {"status": "Error occurred", "detail": str(e)}
    finally:
        con.close()
    return {"status": "Record deleted successfully"}

# Run the FastAPI application
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="localhost", port=8000)
